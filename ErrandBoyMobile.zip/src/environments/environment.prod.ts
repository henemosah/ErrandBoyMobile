/*
  Authors : initappz (Rahul Jograna)
  Website : https://initappz.com/
  App Name : Foodies-3 FoodDon This App Template Source code is licensed as per the
  terms found in the Website https://initappz.com/license
  Copyright and Good Faith Purchasers © 2023-present initappz.
*/
export const environment = {
  production: true,
  firebaseConfig:  {
    apiKey: "AIzaSyCaI5LmgZLzIlMVrVPIBsshffEvdQWGxvM",
    authDomain: "errandboy-fb5b0.firebaseapp.com",
    projectId: "errandboy-fb5b0",
    storageBucket: "errandboy-fb5b0.firebasestorage.app",
    messagingSenderId: "291533970948",
    appId: "1:291533970948:web:c505676bd24c30cdeedf51",
    measurementId: "G-1JX5ZTMD68"
  },
  errandboy_engine_url: "https://errandboy.en2ovatesite.com/"
};
