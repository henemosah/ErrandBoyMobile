/*
  Authors : initappz (Rahul Jograna)
  Website : https://initappz.com/
  App Name : Foodies-3 FoodDon This App Template Source code is licensed as per the
  terms found in the Website https://initappz.com/license
  Copyright and Good Faith Purchasers © 2023-present initappz.
*/
import { Component, OnInit } from '@angular/core';
import { UtilService } from 'src/app/services/util.service';

@Component({
  selector: 'app-set-delivery-location',
  templateUrl: './set-delivery-location.page.html',
  styleUrls: ['./set-delivery-location.page.scss'],
})
export class SetDeliveryLocationPage implements OnInit {

  constructor(
    public util: UtilService
  ) { }

  ngOnInit() {
  }

  onBack() {
    this.util.onBack();
  }

  addNewAddress() {
    this.util.navigateToPage('add-new-address');
  }

}
